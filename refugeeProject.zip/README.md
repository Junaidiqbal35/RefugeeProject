
# Refuge Project

A project for helping ukraine refuges to find houses.



## Installation

Install project with venv

```bash
  python -m venv venv
  cd RefugeeProject
  pip Install -r requirements.txt
  python manage.py runserver
```
    

