from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.accommodation_create, name='create_accommodation'),
    path('', views.accommodation_list, name='home'),
    # path('create/', views.CreateAccommodationView.as_view(), name='create_accommodation'),
    path('accommodation/<int:pk>/', views.accommodation_detail, name='detail_accommodation'),
    path('accommodation/search/', views.accommodation_search, name='accommodation_search'),
]
