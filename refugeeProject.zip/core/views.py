from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import Http404
from django.shortcuts import render, redirect

# Create your views here.

from core.forms import AccommodationForm
from core.models import Accommodation


@login_required
def accommodation_create(request):
    if request.method == 'POST':
        # form is sent
        form = AccommodationForm(request.POST)
        if form.is_valid():
            # form data is valid
            accommodation_form = form.save(commit=False)
            # assign current user to the item
            accommodation_form.user = request.user
            accommodation_form.save()
            messages.success(request,
                             'Accommodation added successfully')
            # redirect to new created item detail view
            return redirect('/')
    else:
        form = AccommodationForm
    return render(request,
                  'core/create_accommodation.html',
                  {
                      'form': form})


def accommodation_list(request):
    queryset = Accommodation.objects.filter(available=True)
    return render(request,
                  'core/index.html',
                  {'accommodation_object': queryset})


def accommodation_detail(request, pk):
    try:
        accommodation = Accommodation.objects.get(id=pk)
    except accommodation.DoesNotExist:
        raise Http404("No Accommodation found.")
    return render(request,
                  'core/accommodation_detail.html',
                  {'accommodation_object': accommodation})


def accommodation_search(request):
    if request.GET.get('search'):
        query = request.GET.get('search')
        payment_method = request.GET.get('payment_method')

        results = Accommodation.objects.filter(Q(city__icontains=query) | Q(num_of_guests__icontains=query) |
                                               Q(payment_method=2))
        print(results)

        return render(request,
                      'core/index.html',
                      {
                          'query': query,
                          'accommodation_object': results})

    if request.GET.get('payment_method'):
        payment_method = request.GET.get('payment_method')

        results = Accommodation.objects.filter(payment_method=payment_method)
        print(results)

        return render(request,
                      'core/index.html',
                      {
                          'query': payment_method,
                          'accommodation_object': results})